<?php
#---------------------------------------------------------------------------------------------------
# Module: Allinoneaccessibility
# Author: Skynet Technologies USA LLC
# Copyright: (C) 2023 Skynet Technologies USA LLC, hello@skynettechnologies.com
# Licence: GNU General Public License version 3
#          see /Allinoneaccessibility/lang/LICENCE.txt or <http://www.gnu.org/licenses/gpl-3.0.html>
#---------------------------------------------------------------------------------------------------

if( !defined('CMS_VERSION') ) exit;

if( !$this->CheckPermission(Allinoneaccessibility::MANAGE_PERM) ) return;
    
$aioa_website_hostname = parse_url($config['root_url'], PHP_URL_HOST);
 
$curl = curl_init();
curl_setopt_array($curl, array(
CURLOPT_URL => 'https://ada.skynettechnologies.us/check-website',
CURLOPT_RETURNTRANSFER => true,
CURLOPT_ENCODING => '',
CURLOPT_MAXREDIRS => 10,
CURLOPT_TIMEOUT => 0,
CURLOPT_FOLLOWLOCATION => true,
CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
CURLOPT_CUSTOMREQUEST => 'POST',
CURLOPT_POSTFIELDS => array('domain' =>  $aioa_website_hostname),
));

$response = curl_exec($curl);

curl_close($curl);
$settingURLObject = json_decode($response);

 // fetch User name and email 
    if (!defined('CMS_VERSION')) exit;

        $userops = \UserOperations::get_instance();
        $userid = get_userid(); // gets current logged-in admin user ID

        if ($userid) {
            $user1 = $userops->LoadUserByID($userid);
        $username = $user1->username;
            $email = $user1->email;
        } else {
            echo 'No admin user is logged in.';
        }


    // Prepare data object for Smarty template
    $dataObj = [
        'username' => $username,
        'email' => $email,
        'settinglink' => $settingURLObject->settinglink,
        'status' => $settingURLObject->status,
        'manage_domain' => $settingURLObject->manage_domain,
        'aioa_website_hostname' => $aioa_website_hostname
    ];

    // Convert to object and assign to Smarty template
    $data = (object) $dataObj;
    $tpl = $smarty->CreateTemplate($this->GetTemplateResource('defaultadmin.tpl'), null, null, $smarty);
    $tpl->assign('data', $data);
    $tpl->display();

