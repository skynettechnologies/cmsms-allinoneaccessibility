<?php
    $lang['friendlyname'] = 'All in One Accessibility™';
    $lang['admindescription'] = 'All in One Accessibility widget improves website ADA compliance and browser experience for ADA, WCAG 2.1 & 2.2, Section 508, Australian DDA, European EAA EN 301 549, UK Equality Act (EA), Israeli Standard 5568, California Unruh, Ontario AODA, Canada ACA, German BITV, France RGAA, Brazilian Inclusion Law (LBI 13.146/2015), Spain UNE 139803:2012, JIS X 8341 (Japan), Italian Stanca Act and Switzerland DDA Standards. All in One Accessibility Widget complies with GDPR, COPPA regulations.';
    $lang['ask_uninstall'] = 'Are you sure you want to uninstall the Allinoneaccessibility module? All setting
    data will be permanently deleted.';
    $lang['setting_saved'] = 'Setting Saved Successfully';
?>
